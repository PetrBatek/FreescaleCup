#ifndef TFC_PWM_MOTOR_H_
#define TFC_PWM_MOTOR_H_

void TFC_InitMotorPWM();
void TFC_SetMotorPWM(float MotorA ,float MotorB);

#endif /* TFC_PWM_MOTOR_H_ */
